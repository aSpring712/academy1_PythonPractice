print("******* 시작 ******")

Num = 1004
String = '지옥으로 키티'

def Spring_Function():
    print("여기는 Spring02.py 파일 안 입니다")

print("******* 끗 ******")