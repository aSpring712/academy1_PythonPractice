def Spring2():
    print('스프링2가 호출됩니다')