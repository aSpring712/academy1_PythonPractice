print('1')
import Spring02 as S
print('2')
import Spring02
print('3')
import Spring02
print('4')

Spring02.Spring_Function()
S.Spring_Function()
print(S.Num)
print(S.String)

from Sub import Test as T
from Sub import Test

Test.Spring2()
T.Spring2()
