Number = input('숫자를 입력하세요 : ')
Number = int(Number)
if 50 > Number :
    print('입력한 숫자는 50보다 작습니다.')
else :
    print('입력한 숫자는 50보다 큼니다.')