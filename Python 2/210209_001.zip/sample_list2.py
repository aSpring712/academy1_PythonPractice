array = [100, 200, 300, 400]

print(array[0])
print(array[1])
print(array[2])
print(array[3])

for i in array:
    print(i)