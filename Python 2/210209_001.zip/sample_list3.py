array = []
array.append(101)
array.append(202)
array.append(303)
array.append(404)
for i in array:
    print(i)

array.remove(202)
for i in array:
    print(i)