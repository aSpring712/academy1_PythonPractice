a = 123
a = a + 1
print(type(a))
print(a)
a = a + 3.14
print(type(a))
print(a)
a = '지옥으로 키티'
print(type(a))
print(a)
a = input()
print(type(a))
print(a)
a = int(input())
print(type(a))
print(a)