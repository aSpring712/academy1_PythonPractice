a, b, c, d = 100, 200, 300, 400

print(a)
print(b)
print(c)
print(d)
