# int iNum = 100; <= 자바 문법
iNum = 100 # 파이썬 문법
iNum = iNum + 300

# System.out.println(iNum); <= 자바 문법
print(iNum)
