aDict1 = dict(test=100, spring=200)
aDict2 = dict({'test':100, 'spring':200})
aDict3 = {'test':100, 'spring':200}
aDict4 = dict([('test',100), ('spring',200)])
print(aDict1)
print(aDict2)
print(aDict3)
print(aDict4)