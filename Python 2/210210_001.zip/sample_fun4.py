def spring(Num1, Num2):
    return Num1 + 1000, Num2 + 2000

Temp = spring(100, 200)
RetVal1, RestVal2 = spring(111,222)
print(Temp)
print(RetVal1)
print(RestVal2)
