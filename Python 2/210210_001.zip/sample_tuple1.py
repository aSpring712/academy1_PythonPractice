aTuple = '지옥으로 키티' # 문자형 튜플

print(aTuple)
print(aTuple[0])    # '지' 만 출력
print(aTuple[-1])   # '티' 만 출력
print(aTuple[6])    # '티' 만 출력
#aTuple[0] = '개'   # 튜플(문자열형 튜플)은 변경 불가(List와 차이점)