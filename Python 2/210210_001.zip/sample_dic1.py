aDict = {'이름':'홍길동', '나이': 50, 10:"10만원"}

print(aDict)
print(type(aDict))
print(aDict['이름'])
print(aDict['나이']) 
print(aDict[10]) 