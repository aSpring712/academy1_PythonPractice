def spring(Num):
    print('---------------')
    print(Num)
    print('---------------')

spring(100)
spring(200)