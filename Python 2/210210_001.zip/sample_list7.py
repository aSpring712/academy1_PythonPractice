aList = [   [0,1,2],
            [3,4,5],
            [7,8,9]]

print(aList)
aList.extend([[10,20,30]])
print(aList)
print(aList[3][0]) # 10
print(aList[3][1]) # 20

#print(aList)
#aList.extend([10,20,30])
#print(aList)
#print(aList[3]) # 10
#print(aList[4]) # 20

#print(aList)
#aList[2][1] = 88
#print(aList)

#print(aList[1][1])

#print(aList)
#print(aList[0])
#print(aList[1])
#print(aList[2])