aTuple = 0, '할룽', '여보세욤', 3.14

print(aTuple)
print(type(aTuple[0]))  # 0 출력
print(type(aTuple[1]))  # '할룽' 출력
print(type(aTuple[3]))  # 3.14 출력
print(aTuple[2][3])     # '욤' 출력
print(aTuple[2][-1])    # '욤' 출력

#aTuple = 0, 1, 2
#print(aTuple)