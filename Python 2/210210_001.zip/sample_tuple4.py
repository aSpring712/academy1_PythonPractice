aTuple = 3, 4, 5
aTuple2 = aTuple * 3

print(aTuple)
print(aTuple2)
print(len(aTuple))
print(len(aTuple2))