def spring(Num1, Num2):
    return Num1 + Num2

Temp = spring(3,5)
print(Temp)
