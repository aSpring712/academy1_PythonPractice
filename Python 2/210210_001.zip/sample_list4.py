aList = []

for Temp in range(0, 100):
    aList.append(Temp)

print(aList)