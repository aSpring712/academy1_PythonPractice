aList = [23, 65, 34, 3, 35, 5, 55]
print(aList)

aList.append(34)
print(aList)
print(aList.count(34))

#aList.clear()
#print(aList)

#aList2 = [1, 99, 200, 300]
#aList.extend(aList2)
#print(aList)

#aList.extend([1, 99, 200])
#print(aList)


#Temp = aList.pop()
#aList.pop()
#print(aList)
#print(Temp)

#aList.insert(2, 77)
#print(aList)

#aList.sort()
#aList.reverse()
#print(aList)
