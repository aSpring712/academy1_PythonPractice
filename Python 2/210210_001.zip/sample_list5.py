aList = [0,1,2,3,4]  
# Data :  0  1  2  3  4  0 1 2 3 4
# Index: -5 -4 -3 -2 -1  0 1 2 3 4

print(aList[3])
print(aList[-1])
print(aList[-5])
# print(aList[-6]) 안됨 : out of range
# print(aList[5]) 안됨 : out of range