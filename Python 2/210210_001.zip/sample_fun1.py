print('시작')

def spring():
    print('지옥으로 키티')
spring()
print('종료')