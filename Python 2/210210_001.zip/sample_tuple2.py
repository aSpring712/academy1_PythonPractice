aTuple = (1, 2, 3)

aTuple2 = (4, 5, 6)
aTuple = aTuple + aTuple2[1:]
print(aTuple)

#aTuple2 = (4, 5, 6)
#aTuple = aTuple + aTuple2
#print(aTuple)
#print(aTuple2)

#print(aTuple)
#print(aTuple[1:]) # 슬라이싱, 1번자리 이후 모두 출력

#print(aTuple)
#print(aTuple[0])
#aTuple[0] = 100 # 'tuple' object does not support item assignment